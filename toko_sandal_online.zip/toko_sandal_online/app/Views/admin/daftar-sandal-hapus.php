<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Sandal</title>
    <link rel="stylesheet" href="/path/to/your/css/styles.css"> 
</head>
<body>
    <div class="container">
        <h1>Konfirmasi Hapus sandal</h1>

        <?php if (isset($sandal)): ?>
            <p>Apakah Anda yakin ingin menghapus sandal dengan data berikut?</p>
            <ul>
                <li><strong>Nama:</strong> <?= htmlspecialchars($sandal['nama_sandal']); ?></li>
                <li><strong>merk:</strong> Rp <?= number_format($sandal['merk'], 2, ',', '.'); ?></li>
                <li><strong>ukuran:</strong> <?= htmlspecialchars($sandal['ukuran']); ?></li>
            </ul>

            <form action="/admin/daftar-sandal/hapus/<?= $sandal['id']; ?>" method="post">
                <?= csrf_field(); ?> 
                <button type="submit" class="btn btn-danger">Hapus</button>
                <a href="/admin/daftar-sandal" class="btn btn-secondary">Batal</a>
            </form>
        <?php else: ?>
            <p>Data sandal tidak ditemukan.</p>
            <a href="/admin/daftar-sandal" class="btn btn-secondary">Kembali ke Daftar sandal</a>
        <?php endif; ?>
    </div>
</body>
</html>