<?= $this->extend('template') ?>

<?= $this->section('main') ?>
<div class="container">
    <h2>Review Order</h2>
    <hr />
    <h5>Sandal Harian</h5> @1
    <h5>Rp120,000</h5>
    <h5>Sandal Hak 3 cm</h5> @2
    <h5>Rp95,000</h5>
    <h5>Sandal Santai</h5> @1
    <h5>Rp75,000</h5>

    <h2 class="mt-3">Alamat pengiriman</h2>
    <hr />
    <h5>Jl. Muaro Jambi - Muaro Bulian KM 16, Sungai Duren.</h5>

    <h2 class="mt-3">Metode Bayar</h2>
    <hr />
    <h5>Transfer Bank</h5>
    <h5>BRI Elnidwiputri</h5>
    <h5>Rek. 86375486948673</h5>

    <div class="mt-5">
        <form action="<?= base_url('submit')?>" method="POST"  >
            <button type="submit" class="btn btn-success">Submit Order</button>
        </form>
    </div>
</div>
<?= $this->endSection() ?>