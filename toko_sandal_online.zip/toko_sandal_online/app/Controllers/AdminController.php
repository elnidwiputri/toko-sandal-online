<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\SandalsModel;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    public function index() 
    {
        return view('admin/dashboard');
    }

    public function daftarSandal() 
    {
        $sandalModel = new SandalsModel();
        $data['sandals'] = $sandalModel->findAll();
        return view('admin/daftar-sandal', $data);
    }

    public function daftarSandalTambah() 
    {
        return view('admin/daftar-sandal-tambah');
    }

    public function createSandal()
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('cover');

        if ($file && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['cover'] = $path;
        }

        $sandalModel = new SandalsModel();

        if($sandalModel->insert($data,false)) {
            return redirect()->to('admin/daftar-sandal')->with('berhasil','data berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-sandal')->with('gagal','data gagal disimpan!');
        }
    }

    public function daftarSandalEdit($id)
    {
        $sandalModel = new SandalsModel();
        $sandals = $sandalModel->find($id);
    
        if (!$sandals) {
            return redirect()->to('admin/daftar-sandal')->with('gagal', 'Data sepatu tidak ditemukan!');
        }
    
        return view('admin/daftar-sandal-edit', ['sandals' => $sandals]);
    }
    
    public function changeSandal($id)
    {
        $sandalModel = new SandalsModel(); 
        $existingSandal = $sandalModel->find($id); 
    
        if (!$existingSandal) {
            return redirect()->to('admin/daftar-sandal')->with('gagal', 'Data sepatu tidak ditemukan!');
        }
    
        $data = $this->request->getPost(); 
        $file = $this->request->getFile('cover');
    
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['cover'] = $path; 
        } else {
            $data['cover'] = $existingSandal['cover'];
        }
    
        if ($sandalModel->update($id, $data)) {
            return redirect()->to('admin/daftar-sandal')->with('berhasil', 'Data berhasil diperbarui!');
        } else {
            return redirect()->to('admin/daftar-sandal')->with('gagal', 'Data gagal diperbarui!');
        }
    }

    public function hapusSandal($id) 
    {
        $sandalModel = new SandalsModel();
        $sandal = $sandalModel->find($id);

        if ($sandal) {
            $sandalModel->delete($id);
            return redirect()->to('/admin/daftar-sandal')->with('berhasil', 'Data SANDAL berhasil dihapus.');
        }
        return redirect()->to('/admin/daftar-sandal')->with('gagal', 'Data SANDAL tidak ditemukan.');
    }

    public function transaksi() 
    {
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus() 
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus() 
    {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan() 
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus() 
    {
        return view('admin/pelanggan-hapus');
    }
}