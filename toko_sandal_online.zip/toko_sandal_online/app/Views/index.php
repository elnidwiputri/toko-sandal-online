<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko Sandal Elni</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?= base_url()?>css/style.css">
    <style>
      body {
        background-color: #FFC0CB;
      }
      .btn-primary {
        background-color: #FF7043;
        border-color: #FF7043;
      }
      .btn-primary:hover {
        background-color: #F4511E;
        border-color: #F4511E;
      }
      .btn-secondary {
        background-color: #66BB6A;
        border-color: #66BB6A;
      }
      .btn-secondary:hover {
        background-color: #43A047;
        border-color: #43A047;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="row mb-5">
        <div class="col-12 text-end">
          <a href="<?= base_url() ?>chart" class="btn btn-secondary">Keranjang belanja <span class="badge text-bg-warning">4</span></a>
        </div>
      </div>
      <div class="row bg-primary-subtle mb-5">
        <div class="col-6 p-5">
          <h1>Selamat Datang di Toko Elni Dwi Putri</h1>
          <p>Kami menyediakan berbagai jenis sandal berkualitas dari berbagai merek ternama.</p>
          <a href="#" class="btn btn-primary">Lihat Produk</a>
        </div>
        <div class="col-6 p-5">
          <h1>Temukan sandal favorit Anda!</h1>
          <form action="">
            <div class="mb-3">
              <input
                type="text"
                class="form-control"
                placeholder="Nama Sandal"
              />
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="Merek" />
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="Ukuran" />
            </div>
            <div class="mb-3">
              <button class="btn btn-primary">Cari</button>
            </div>
          </form>
        </div>
      </div>

      <h2>Sandal Best Seller</h2>
      <div class="row mb-5 g-3">
        <div class="col-3">
          <div class="card">
            <img src="images/foto1.jpeg" class="card-img-top" alt="Sandal 1" />
            <div class="card-body">
              <h5 class="card-title">Sandal Harian</h5>
              <p class="card-text">
                Rp 120,000,-
              </p>
              <a href="<?= base_url() ?>chart" class="btn btn-custom">
                                <i class="fas fa-cart-plus me-2"></i>Add to Cart
                            </a>
            </div>
          </div>
        </div>
        <div class="col-3">
          <div class="card">
            <img src="images/foto2.jpeg" class="card-img-top" alt="Sandal 2" />
            <div class="card-body">
              <h5 class="card-title">Sandal Hak 3 Cm</h5>
              <p class="card-text">
                Rp 95,000,-
              </p>
                            <a href="<?= base_url() ?>chart" class="btn btn-custom">
                                <i class="fas fa-cart-plus me-2"></i>Add to Cart
                            </a>
            </div>
          </div>
        </div>
        <div class="col-3">
          <div class="card">
            <img src="images/foto3.jpeg" class="card-img-top" alt="Sandal 3" />
            <div class="card-body">
              <h5 class="card-title">Sandal Santai</h5>
              <p class="card-text">
                Rp 75,000,-
              </p>
              <a href="<?= base_url() ?>chart" class="btn btn-custom">
                                <i class="fas fa-cart-plus me-2"></i>Add to Cart
                            </a>
            </div>
          </div>
        </div>
        <div class="col-3">
          <div class="card">
            <img src="images/foto4.jpeg" class="card-img-top" alt="Sandal 4" />
            <div class="card-body">
              <h5 class="card-title">Sandal Wanita</h5>
              <p class="card-text">
                Rp 150,000,-
              </p>
              <a href="<?= base_url() ?>chart" class="btn btn-custom">
                                <i class="fas fa-cart-plus me-2"></i>Add to Cart
                            </a>
            </div>
          </div>
        </div>
      </div>
    </div>


    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
