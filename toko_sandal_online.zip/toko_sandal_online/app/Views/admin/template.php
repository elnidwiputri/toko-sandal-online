<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Toko Sandal Online</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?= base_url()?>css/style.css">
    <style>
      body {
        background-color: #f7f8fc;
        font-family: 'Poppins', sans-serif;
      }

      .sidebar {
        background-color: #4A90E2;
        height: 100vh;
        padding-top: 20px;
        border-radius: 0 15px 15px 0;
      }

      .sidebar a {
        color: white;
        font-size: 18px;
        padding: 12px 20px;
        display: block;
        text-decoration: none;
        border-radius: 5px;
        transition: all 0.3s ease;
        margin: 10px 0;
      }

      .sidebar a:hover {
        background-color: #0056b3;
        transform: scale(1.05);
      }

      .main-content {
        padding: 30px;
        background-color: #ffffff;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      }

      .topbar {
        background-color: #ffffff;
        color: #333;
        padding: 15px 30px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin-bottom: 30px;
      }

      .topbar h2 {
        margin: 0;
        font-size: 28px;
        font-weight: 600;
      }

      .topbar .btn {
        background-color: #4A90E2;
        color: white;
        padding: 8px 20px;
        border-radius: 5px;
        text-decoration: none;
        transition: all 0.3s ease;
      }

      .topbar .btn:hover {
        background-color: #0056b3;
        transform: scale(1.05);
      }

      .card {
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
      }

      .card-header {
        background-color: #4A90E2;
        color: white;
        font-size: 20px;
        border-radius: 15px 15px 0 0;
      }

      .card-body {
        padding: 20px;
      }

      .btn-danger {
        background-color: #ff4d4d;
        border-color: #ff4d4d;
        padding: 10px 20px;
        border-radius: 8px;
        transition: all 0.3s ease;
      }

      .btn-danger:hover {
        background-color: #e60000;
        border-color: #e60000;
      }

      .btn-secondary {
        background-color: #9e9e9e;
        border-color: #9e9e9e;
        padding: 10px 20px;
        border-radius: 8px;
        transition: all 0.3s ease;
      }

      .btn-secondary:hover {
        background-color: #757575;
        border-color: #757575;
      }
    </style>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row">
        <div class="col-2 sidebar">
          <ul>
            <li><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
            <li><a href="<?= base_url('admin/daftar-sandal') ?>">Daftar Sandal</a></li>
            <li><a href="<?= base_url('admin/transaksi') ?>">Transaksi</a></li>
            <li><a href="<?= base_url('admin/pelanggan') ?>">Pelanggan</a></li>
          </ul>
        </div>
        <div class="col-10">
          <div class="topbar d-flex justify-content-between align-items-center">
            <h2>Admin Dashboard</h2>
            <a href="<?= base_url('logout') ?>" class="btn">Logout</a>
          </div>

          <div class="main-content">
            <?= $this->renderSection('main'); ?>
          </div>
        </div>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
