<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSandalsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'auto_increment' => true,
            ],
            'nama_sandal' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'merk' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'ukuran' => [
                'type' => 'INT',
                'constraint' => 10,
            ],
            'warna' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'stok' => [
                'type' => 'INT',
                'constraint' => 5,
            ],
            'harga' => [
                'type' => 'INT',
                'constraint' => 16,
            ],
            'cover' => [
                'type' => 'VARCHAR',
                'constraint' => 250,
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->createTable('sandals');
    }

    public function down()
    {
        $this->forge->dropTable('sandals');
    }
}
