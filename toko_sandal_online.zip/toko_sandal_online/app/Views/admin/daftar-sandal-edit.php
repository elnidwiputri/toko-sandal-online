<?= $this->extend('admin/template') ?>

<?= $this->section('main') ?>

<h2 class="mb-5">Edit Sandal</h2>

<form action="<?= base_url('admin/daftar-sandal/change/'.$sandals['id']); ?>" method="post" enctype="multipart/form-data">


    <div class="mb-3">
        <label for="nama_sandal" class="form-label">Nama sandal</label>
        <input type="text" class="form-control w-50" id="nama_sandal"
            placeholder="nama_sandal" name="nama_sandal" value="<?= $sandals['nama_sandal']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="merk" class="form-label">merk</label>
        <input type="text" class="form-control" id="merk" name="merk" value="<?= $sandals['merk']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="ukuran" class="form-label">Ukuran</label>
        <input type="teks" class="form-control" id="ukuran" name="ukuran" value="<?= $sandals['ukuran']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="warna" class="form-label">Warna</label>
        <input type="text" class="form-control" id="warna" name="warna" value="<?= $sandals['warna']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="stok" class="form-label">Stok</label>
        <input type="number" class="form-control" id="stok" name="stok" value="<?= $sandals['stok']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="harga" class="form-label">Harga</label>
        <input type="number" class="form-control" id="harga" name="harga" value="<?= $sandals['harga']; ?>"
            autocomplete="off" required>
    </div>
    <!-- <div class="mb-3">
        <label for="cover" class="form-label">Gambar Sandal Baru Jika Mau</label>
        <input type="file" class="form-control" id="cover" name="cover" autocomplete="off">
        
    </div> -->
    <div class="mb-3">
        <a href="<?= base_url('admin/daftar-sandal') ?>" class="btn btn-secondary">Kembali</a>
        <button type="submit" class="btn btn-primary">Ubah</button>
    </div>
</form>

<?= $this->endSection() ?>