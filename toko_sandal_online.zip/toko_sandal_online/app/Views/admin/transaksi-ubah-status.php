<?= $this->extend('admin/template')?>

<?= $this->section('main')?>
<h2 class="mb-5">Tambah Produk Sandal</h2>

<div class="w-50">
    <form action="<?= base_url('admin/daftar-produk/tambah')?>" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nama">Nama Produk</label>
            <input type="text" class="form-control" name="nama" id="nama" required>
        </div>
        <div class="mb-3">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="kategori">Kategori</label>
            <select class="form-control" name="kategori" id="kategori">
                <option value="pria">Sandal Pria</option>
                <option value="wanita">Sandal Wanita</option>
                <option value="anak">Sandal Anak</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="harga">Harga</label>
            <input type="number" class="form-control" name="harga" id="harga" required>
        </div>
        <div class="mb-3">
            <label for="stok">Stok</label>
            <input type="number" class="form-control" name="stok" id="stok" required>
        </div>
        <div class="mb-3">
            <label for="gambar">Gambar Produk</label>
            <input type="file" class="form-control" name="gambar" id="gambar" required>
        </div>
        <div class="mb-3">
            <a href="<?= base_url('admin/daftar-produk')?>" class="btn btn-secondary">Batal</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>

<?= $this->endSection()?>
