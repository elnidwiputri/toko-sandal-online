<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Shopping - Toko Sandal Elni Dwi Puti</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <style>
      .navbar-custom {
        background: linear-gradient(135deg, #FF69B4, #FF1493);
      }
      .cart-item {
        background: white;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        transition: transform 0.3s ease;
        border: 1px solid #FFE4E1;
      }
      .cart-item:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 16px rgba(0,0,0,0.12);
      }
      .cart-image {
        width: 140px;
        height: 140px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid #FFE4E1;
      }
      .product-name {
        font-size: 1.3rem;
        font-weight: 600;
        color: #FF1493;
      }
      .quantity-badge {
        background: #FF69B4;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        box-shadow: 0 2px 4px rgba(255,105,180,0.3);
      }
      .delete-btn {
        border-radius: 50%;
        width: 45px;
        height: 45px;
        padding: 0;
        line-height: 45px;
        text-align: center;
        transition: all 0.4s ease;
        background-color: #FFE4E1;
        color: #FF1493;
        border: none;
      }
      .delete-btn:hover {
        transform: rotate(90deg);
        background-color: #FF1493;
        color: white;
      }
      .total-section {
        background: linear-gradient(135deg, #FF69B4, #FF1493);
        color: white;
        border-radius: 20px;
        padding: 2.5rem;
        box-shadow: 0 8px 16px rgba(255,20,147,0.2);
      }
      .btn-custom {
        border-radius: 30px;
        padding: 1rem 2.5rem;
        font-weight: 600;
        transition: all 0.3s ease;
        letter-spacing: 0.5px;
      }
      .btn-custom:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      }
      .footer {
        background: linear-gradient(135deg, #FF69B4, #FF1493);
        color: white;
      }
      
      @keyframes removeItem {
        0% {
          opacity: 1;
          transform: translateX(0);
        }
        100% {
          opacity: 0;
          transform: translateX(-100%);
          height: 0;
          margin: 0;
          padding: 0;
        }
      }
      
      .cart-item.removing {
        animation: removeItem 0.6s ease forwards;
      }
    </style>
  </head>
  <body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
      <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-flower me-2"></i>Toko Sandal Elni Dwi Putri</a>
      </div>
    </nav>

    <div class="container py-4">
      <div class="row mb-4">
        <div class="col-12">
          <h1 class="text-center mb-3">
            <i class="fas fa-shopping-basket me-2"></i>Your Sandals
          </h1>
          <p class="text-center text-muted">Best Sandals selected with love</p>
        </div>
      </div>

      <div class="row mb-4">
        <div class="col-lg-8 mb-4" id="cartItemsContainer">
          <!-- Cart Item 1 -->
          <div class="cart-item p-4 mb-3" data-price="150000">
            <div class="row align-items-center">
              <div class="col-md-3 mb-2 mb-md-0 text-center">
                <img src="images/foto1.jpeg" alt="Sandal Harian" class="cart-image" />
              </div>
              <div class="col-md-4 mb-2 mb-md-0">
                <h5 class="product-name mb-2">Sandal Harian</h5>
                <p class="text-muted mb-0">Sandal yang nyaman untuk dipakai sehari-hari</p>
              </div>
              <div class="col-md-2 mb-2 mb-md-0 text-center">
                <span class="quantity-badge">
                  <i class="fas fa-times me-1"></i>1
                </span>
              </div>
              <div class="col-md-2 mb-2 mb-md-0 text-center">
                <span class="fw-bold">Rp 120.000</span>
              </div>
              <div class="col-md-1 text-end">
                <button class="btn delete-btn" onclick="removeCartItem(this)">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Cart Item 2 -->
          <div class="cart-item p-4 mb-3" data-price="200000">
            <div class="row align-items-center">
              <div class="col-md-3 mb-2 mb-md-0 text-center">
                <img src="images/foto2.jpeg" alt="Sandal Hak 3 Cm" class="cart-image" />
              </div>
              <div class="col-md-4 mb-2 mb-md-0">
                <h5 class="product-name mb-2">Sandal Hak 3 Cm</h5>
                <p class="text-muted mb-0">Bagus dipakai ke pesta</p>
              </div>
              <div class="col-md-2 mb-2 mb-md-0 text-center">
                <span class="quantity-badge">
                  <i class="fas fa-times me-1"></i>1
                </span>
              </div>
              <div class="col-md-2 mb-2 mb-md-0 text-center">
                <span class="fw-bold">Rp 95.000</span>
              </div>
              <div class="col-md-1 text-end">
                <button class="btn delete-btn" onclick="removeCartItem(this)">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Cart Item 3 -->
          <div class="cart-item p-4 mb-3" data-price="175000">
            <div class="row align-items-center">
              <div class="col-md-3 mb-2 mb-md-0 text-center">
                <img src="images/foto3.jpeg" alt="Sandal Santai" class="cart-image" />
              </div>


              <div class="col-md-4 mb-2 mb-md-0">
                <h5 class="product-name mb-2">Sandal Santai</h5>
                <p class="text-muted mb-0">Sandal yang nyaman untuk bersantai</p>
                
              </div>
              <div class="col-md-2 mb-2 mb-md-0 text-center">
                <span class="quantity-badge">
                  <i class="fas fa-times me-1"></i>1
                </span>
              </div>
              <div class="col-md-2 mb-2 mb-md-0 text-center">
                <span class="fw-bold">Rp 75.000</span>
              </div>
              <div class="col-md-1 text-end">
                <button class="btn delete-btn" onclick="removeCartItem(this)">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="total-section">
            <h4 class="mb-4">Order Summary</h4>
            <div class="d-flex justify-content-between mb-3">
              <span>Subtotal</span>
              <span id="subtotal">Rp 290.000</span>
            </div>
            <div class="d-flex justify-content-between mb-3">
              <span>Shipping</span>
              <span>Free</span>
            </div>
            <hr class="text-light">
            <div class="d-flex justify-content-between mb-4">
              <h5 class="mb-0">Total</h5>
              <h5 class="mb-0" id="totalAmount">Rp 290.000</h5>
            </div>
            <div class="d-grid gap-3">
              <a href="<?= base_url('checkout')?>" class="btn btn-light btn-custom">
                <i class="fas fa-credit-card me-2"></i>Proceed to Checkout
              </a>
              <a href="<?= base_url()?>" class="btn btn-outline-light btn-custom">
                <i class="fas fa-arrow-left me-2"></i>Continue Shopping
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
      function formatCurrency(amount) {
        return 'Rp ' + amount.toLocaleString() + ',-';
      }
      
      function updateTotals() {
        const cartItems = document.querySelectorAll('.cart-item:not(.removing)');
        let total = 0;
        
        cartItems.forEach(item => {
          const price = parseInt(item.dataset.price);
          total += price;
        });
        
        document.getElementById('subtotal').textContent = formatCurrency(total);
        document.getElementById('totalAmount').textContent = formatCurrency(total);
        
        const cartBadge = document.querySelector('.badge');
        if (cartBadge) {
          cartBadge.textContent = cartItems.length;
        }
      }
      
      function removeCartItem(button) {
        const cartItem = button.closest('.cart-item');
        cartItem.classList.add('removing');
        
        setTimeout(() => {
          cartItem.remove();
          updateTotals();
          
          if (document.querySelectorAll('.cart-item').length === 0) {
            const container = document.getElementById('cartItemsContainer');
            container.innerHTML = `
              <div class="text-center p-5">
                <i class="fas fa-flower fa-3x text-muted mb-3"></i>
                <h3>Your cart is empty</h3>
                <p class="text-muted">Add some beautiful Sandals to your cart!</p>
                <a href="<?= base_url()?>" class="btn btn-primary btn-custom mt-3">
                  <i class="fas fa-shopping-basket me-2"></i>Browse Sandals
                </a>
              </div>
            `;
          }
        }, 600);
      }
    </script>
  </body>
</html> 